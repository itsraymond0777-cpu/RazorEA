# ⚔ Razor EA — Android Trading Bot
## SMC + CRT Strategy | XAUUSD | Deriv & FTMO

---

## 📱 How to Get Your APK (3 Methods — All Free)

---

### ✅ METHOD 1: GitHub Actions (EASIEST — No install needed)
**Get the APK automatically built in the cloud in ~5 minutes.**

1. Create a free account at **github.com**
2. Create a new repository (public or private)
3. Upload this entire `RazorEA` folder to the repo
4. Go to **Actions** tab → The `Build Razor EA APK` workflow starts automatically
5. Wait ~5 minutes → Click the finished job → Download `RazorEA-Debug-APK`
6. Transfer the `.apk` to your Android phone and install it

> ✅ **No Android Studio, no laptop setup required — just GitHub.**

---

### ✅ METHOD 2: Android Studio (Full control)

1. Download **Android Studio** free from: `developer.android.com/studio`
2. Open Android Studio → `File → Open` → select the `RazorEA` folder
3. Wait for Gradle sync (downloads dependencies automatically, ~2–5 min)
4. **Add Orbitron font** (free from Google Fonts):
   - Download `Orbitron` from `fonts.google.com/specimen/Orbitron`
   - Copy `Orbitron-Bold.ttf` → `app/src/main/res/font/orbitron_bold_ttf.ttf`
   - Copy `Orbitron-Regular.ttf` → `app/src/main/res/font/orbitron_regular_ttf.ttf`
5. Click **▶ Run** (installs directly to phone) OR
   `Build → Build Bundle(s)/APK(s) → Build APK(s)`
6. APK saved to: `app/build/outputs/apk/debug/app-debug.apk`

---

### ✅ METHOD 3: Online APK Builder — ApkOnline.net

1. Go to `apkonline.net`
2. Zip the `RazorEA` folder → Upload
3. Build and download APK directly

---

## 📲 Installing on Android

1. Transfer the `.apk` to your phone (via USB, Google Drive, WhatsApp)
2. Open the file → tap **Install**
3. If blocked: Settings → Security → **Allow from this source**
4. Open **Razor EA**

### First-time Setup:
| Permission | How to Grant |
|---|---|
| Overlay (display over apps) | Settings → Apps → Razor EA → Display over other apps → ON |
| Accessibility | Settings → Accessibility → Razor EA → ON |
| Notifications | Allow when prompted |

---

## 🔌 Connecting to Deriv / FTMO

### Deriv:
- **Broker:** Deriv
- **Server:** `DerivSVG-Server-03` (or check your MT5 login email)
- **Login:** Your MT5 account number
- **Password:** Your MT5 password

### FTMO:
- **Broker:** FTMO
- **Server:** Check FTMO client area → MT5 credentials
- **Login:** FTMO account number
- **Password:** FTMO MT5 password

> ⚠️ **Important:** Tap **METATRADER** tab → Fill credentials → **Connect Account**
> The EA uses the **MetaApi bridge** to connect — you need either:
> - A **MetaApi free account** (metaapi.cloud) — paste your API token in Settings, OR
> - A **VPS** running the included Python bridge script

---

## 🐍 Optional: VPS Bridge Script (for direct connection without MetaApi)

If you have a VPS with MT5 installed, run this bridge on your VPS:

```python
# bridge.py — Run on VPS with MT5 installed
# pip install MetaTrader5 websockets asyncio

import asyncio, json
import MetaTrader5 as mt5
import websockets

async def handler(ws):
    async for msg in ws:
        cmd = json.loads(msg)
        if cmd["type"] == "auth":
            mt5.initialize()
            mt5.login(int(cmd["login"]), cmd["password"], cmd["server"])
            info = mt5.account_info()
            await ws.send(json.dumps({
                "type": "account",
                "balance": info.balance,
                "equity": info.equity,
                "leverage": info.leverage,
                "currency": info.currency
            }))
        elif cmd["type"] == "subscribe":
            tick = mt5.symbol_info_tick(cmd["symbol"])
            await ws.send(json.dumps({
                "type": "tick", "symbol": cmd["symbol"],
                "bid": tick.bid, "ask": tick.ask
            }))
        elif cmd["type"] == "order":
            req = {
                "action": mt5.TRADE_ACTION_PENDING,
                "symbol": cmd["symbol"],
                "volume": cmd["volume"],
                "type": mt5.ORDER_TYPE_BUY_LIMIT if "BUY" in cmd["action"] else mt5.ORDER_TYPE_SELL_LIMIT,
                "price": cmd["price"],
                "sl": cmd["sl"], "tp": cmd["tp"],
                "comment": cmd["comment"], "magic": cmd["magic"]
            }
            result = mt5.order_send(req)
            await ws.send(json.dumps({"type": "trade_result", "retcode": result.retcode}))

async def main():
    async with websockets.serve(handler, "0.0.0.0", 8765):
        print("Bridge running on port 8765")
        await asyncio.Future()

asyncio.run(main())
```

Then in the Razor EA app: Settings → VPS Bridge URL → `ws://YOUR_VPS_IP:8765`

---

## ⚙️ Strategy Settings (configurable in-app)

| Setting | Default | Description |
|---|---|---|
| Risk per trade | 1% | % of balance risked |
| Max daily DD | 3% | EA pauses if exceeded |
| Max consec losses | 3 | Auto-pause protection |
| Min R:R | 1:2 | Skips low-quality setups |
| Max spread | 30 pts | Filter for wide spreads |
| London session | 02:00–05:00 EST | Primary trading window |
| NY session | 08:00–10:00 EST | Secondary trading window |
| SL buffer | 150 pts | Beyond manipulation wick |
| TP1 partial | 50% | Close half at CRT mid |

---

## 📁 Project Structure

```
RazorEA/
├── .github/workflows/build_apk.yml   ← GitHub auto-build
├── app/src/main/
│   ├── AndroidManifest.xml            ← All permissions declared
│   ├── java/com/razorEA/
│   │   ├── engine/TradingEngine.kt    ← SMC+CRT full logic
│   │   ├── network/MT5ConnectionService.kt ← MT5 WebSocket
│   │   ├── service/OverlayService.kt  ← Floating widget
│   │   ├── service/TradingService.kt  ← Background EA
│   │   ├── service/RazorAccessibilityService.kt
│   │   ├── ui/MainActivity.kt
│   │   ├── ui/HomeFragment.kt         ← Main screen
│   │   ├── ui/ConnectFragment.kt      ← MT5 login
│   │   └── model/Models.kt            ← All data models
│   └── res/layout/                    ← All UI layouts
└── README.md
```

---

## 🔑 License Keys

- Format: `RAZOR-DEMO-XXXX-XXXX` for demo
- Add in: **+ ADD KEY** tab → Enter key → Add License
- Demo key (free): `RAZOR-DEMO-2025-FREE`

---

## ⚠️ Disclaimer

This EA is for educational purposes. Trading involves significant risk of loss.
Always test on a **demo account** before going live. Past performance does not 
guarantee future results. The developer is not responsible for any trading losses.
