package com.razorEA.bot

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class RazorEAApp : Application() {

    companion object {
        const val CHANNEL_TRADING  = "razor_ea_trading"
        const val CHANNEL_OVERLAY  = "razor_ea_overlay"
        const val CHANNEL_ALERTS   = "razor_ea_alerts"

        lateinit var instance: RazorEAApp
            private set

        fun getContext(): Context = instance.applicationContext
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)

            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_TRADING,
                "Razor EA — Trading",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "EA trading activity and status"
                setShowBadge(false)
            })

            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_OVERLAY,
                "Razor EA — Overlay",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Floating overlay service"
                setShowBadge(false)
            })

            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_ALERTS,
                "Razor EA — Trade Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Trade execution alerts"
                enableVibration(true)
            })
        }
    }
}
