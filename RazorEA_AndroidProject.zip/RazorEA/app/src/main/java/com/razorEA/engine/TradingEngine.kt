package com.razorEA.bot.engine

import com.razorEA.bot.model.*
import kotlinx.coroutines.flow.StateFlow
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs

/**
 * TradingEngine
 *
 * Full SMC + CRT strategy implementation in Kotlin.
 * This is the heart of Razor EA — mirrors the MQL5 EA logic.
 *
 * Flow: H4 Bias → H1 POI → M15 CRT → M5 Entry → Risk sizing → Signal
 */
class TradingEngine(
    private val config: RiskConfig = RiskConfig(),
    private val onSignal: (TradeSignal) -> Unit,
    private val onLog: (LogLevel, String) -> Unit
) {
    // ── State ──────────────────────────────────────────────────────
    private var h4Bias      = Bias.NONE
    private var h1OB: OrderBlock?       = null
    private var h1FVG: FairValueGap?    = null
    private var h4FVG: FairValueGap?    = null
    private var crtSetup    = CRTSetup()
    private var eaState     = EAState()
    private var lastDayStart: Long = 0L
    private var sessionTradeCount = 0
    private var consecLosses = 0
    private var isPaused = false
    private var dayStartBalance = 0.0

    // ════════════════════════════════════════════
    // MAIN ENGINE TICK  — call on every new M15 bar
    // ════════════════════════════════════════════

    fun onNewBar(
        h4: List<Candle>,
        h1: List<Candle>,
        m15: List<Candle>,
        m5: List<Candle>,
        balance: Double,
        equity: Double
    ) {
        if (isPaused) return
        if (h4.size < 20 || h1.size < 20 || m15.size < 10) return

        checkDailyReset(balance)
        if (!isSessionActive()) return
        if (sessionTradeCount >= config.maxTradesPerSession) return

        // Step 1: HTF Bias
        val smcAnalysis = analyzeHTF(h4, h1)
        h4Bias = smcAnalysis.h4Bias
        h1OB   = smcAnalysis.h1OB
        h1FVG  = smcAnalysis.h1FVG

        if (h4Bias == Bias.NONE) { log(LogLevel.DEBUG, "No H4 bias"); return }

        // Step 2: CRT on M15
        processCRT(m15, smcAnalysis)

        // Step 3: Entry on M5 (if CRT ready)
        if (crtSetup.valid && crtSetup.state == CRTState.WAIT_ENTRY) {
            checkM5Entry(m5, balance)
        }
    }

    // ════════════════════════════════════════════
    // STEP 1 — HTF ANALYSIS
    // ════════════════════════════════════════════

    private fun analyzeHTF(h4: List<Candle>, h1: List<Candle>): SMCAnalysis {
        // Find major swing points on H4
        val h4SwingHigh = findSwingHigh(h4, 5)
        val h4SwingLow  = findSwingLow(h4, 5)

        val swingH = h4.getOrNull(h4SwingHigh)?.high ?: return SMCAnalysis()
        val swingL = h4.getOrNull(h4SwingLow)?.low   ?: return SMCAnalysis()
        val eq     = swingL + (swingH - swingL) * 0.5 // 50% equilibrium
        val price  = h4.first().close

        // Market structure: HH+HL = bull, LH+LL = bear
        val bias = detectBias(h4)

        // Premium / Discount filter
        val inDiscount = price < eq
        val inPremium  = price > eq

        val finalBias = when {
            bias == Bias.BULL && inDiscount -> Bias.BULL
            bias == Bias.BEAR && inPremium  -> Bias.BEAR
            else -> Bias.NONE
        }

        val h4OB  = findOrderBlock(h4, finalBias, "H4")
        val h4Fvg = findFVG(h4, finalBias, "H4")
        val h1OB  = findOrderBlock(h1, finalBias, "H1")
        val h1Fvg = findFVG(h1, finalBias, "H1")

        log(LogLevel.DEBUG, "H4 Bias: $finalBias | EQ: %.2f | Discount: $inDiscount | OB: ${h1OB?.low}–${h1OB?.high}".format(eq))

        return SMCAnalysis(
            h4Bias      = finalBias,
            h1Bias      = finalBias,
            h4OB        = h4OB,
            h1OB        = h1OB,
            h4FVG       = h4Fvg,
            h1FVG       = h1Fvg,
            equilibrium = eq,
            inDiscount  = inDiscount,
            inPremium   = inPremium
        )
    }

    private fun detectBias(candles: List<Candle>): Bias {
        if (candles.size < 10) return Bias.NONE
        val recentHighs = candles.take(5).map { it.high }
        val priorHighs  = candles.drop(5).take(5).map { it.high }
        val recentLows  = candles.take(5).map { it.low }
        val priorLows   = candles.drop(5).take(5).map { it.low }

        val hh = recentHighs.max() > priorHighs.max()
        val hl = recentLows.min()  > priorLows.min()
        val lh = recentHighs.max() < priorHighs.max()
        val ll = recentLows.min()  < priorLows.min()

        return when {
            hh && hl -> Bias.BULL
            lh && ll -> Bias.BEAR
            else     -> Bias.NONE
        }
    }

    // ════════════════════════════════════════════
    // STEP 2 — CRT STATE MACHINE (M15)
    // ════════════════════════════════════════════

    private fun processCRT(m15: List<Candle>, smc: SMCAnalysis) {
        when (crtSetup.state) {

            // Wait for Reference candle (bar 2 = closed 2 bars ago)
            CRTState.WAIT_REF -> {
                val ref = m15.getOrNull(2) ?: return
                crtSetup = CRTSetup(
                    refHigh  = ref.high,
                    refLow   = ref.low,
                    refMid   = (ref.high + ref.low) / 2.0,
                    state    = CRTState.WAIT_MANIP,
                    session  = getCurrentSession()
                )
                log(LogLevel.DEBUG, "CRT: Reference candle set H=${ref.high} L=${ref.low} Mid=${crtSetup.refMid}")
            }

            // Detect Manipulation (sweep + touch H1 POI)
            CRTState.WAIT_MANIP -> {
                val manip = m15.getOrNull(1) ?: return
                val buf   = 5 * 0.01 // 5 pip buffer for XAUUSD

                val ob  = smc.h1OB
                val fvg = smc.h1FVG

                val touchesPOI: (Double) -> Boolean = { extreme ->
                    (ob  != null && extreme >= ob.low  && extreme <= ob.high) ||
                    (fvg != null && extreme >= fvg.bottom && extreme <= fvg.top)
                }

                when (h4Bias) {
                    Bias.BULL -> {
                        // Sweep below ref low, close back above
                        if (manip.low < crtSetup.refLow - buf &&
                            manip.close > crtSetup.refLow &&
                            touchesPOI(manip.low)) {
                            crtSetup = crtSetup.copy(
                                manipWick = manip.low,
                                state     = CRTState.WAIT_DISPLACE
                            )
                            log(LogLevel.INFO, "CRT: ✅ BULL manipulation @ ${manip.low}")
                        }
                    }
                    Bias.BEAR -> {
                        // Sweep above ref high, close back below
                        if (manip.high > crtSetup.refHigh + buf &&
                            manip.close < crtSetup.refHigh &&
                            touchesPOI(manip.high)) {
                            crtSetup = crtSetup.copy(
                                manipWick = manip.high,
                                state     = CRTState.WAIT_DISPLACE
                            )
                            log(LogLevel.INFO, "CRT: ✅ BEAR manipulation @ ${manip.high}")
                        }
                    }
                    Bias.NONE -> {}
                }

                // Timeout: reset after 8 bars
                crtWaitCount++
                if (crtWaitCount > 8) resetCRT()
            }

            // Displacement Candle (strong body close past CRT Mid + FVG)
            CRTState.WAIT_DISPLACE -> {
                val disp = m15.getOrNull(1) ?: return
                val prev = m15.getOrNull(2) ?: return

                val body  = abs(disp.close - disp.open)
                val range = disp.high - disp.low
                val bodyRatio = if (range > 0) body / range else 0.0

                if (bodyRatio < config.slBufferPoints.toDouble() / 1000) return // weak candle

                when (h4Bias) {
                    Bias.BULL -> {
                        if (disp.close > crtSetup.refMid && bodyRatio >= 0.6) {
                            val fvgBottom = maxOf(prev.high, disp.low)
                            val fvgTop    = disp.high
                            if (fvgTop > fvgBottom) {
                                val fvg = FairValueGap(fvgTop, fvgBottom, isBullish = true, timeframe = "M15")
                                crtSetup = crtSetup.copy(
                                    displaceFVG = fvg,
                                    state       = CRTState.WAIT_ENTRY,
                                    valid       = true
                                )
                                log(LogLevel.INFO, "CRT: ✅ BULL displacement | FVG $fvgBottom–$fvgTop")
                            }
                        }
                    }
                    Bias.BEAR -> {
                        if (disp.close < crtSetup.refMid && bodyRatio >= 0.6) {
                            val fvgTop    = minOf(prev.low, disp.high)
                            val fvgBottom = disp.low
                            if (fvgTop > fvgBottom) {
                                val fvg = FairValueGap(fvgTop, fvgBottom, isBullish = false, timeframe = "M15")
                                crtSetup = crtSetup.copy(
                                    displaceFVG = fvg,
                                    state       = CRTState.WAIT_ENTRY,
                                    valid       = true
                                )
                                log(LogLevel.INFO, "CRT: ✅ BEAR displacement | FVG $fvgBottom–$fvgTop")
                            }
                        }
                    }
                    Bias.NONE -> {}
                }

                dispWaitCount++
                if (dispWaitCount > 4) resetCRT()
            }

            CRTState.WAIT_ENTRY -> { /* handled in M5 checker */ }
            CRTState.COMPLETE   -> resetCRT()
        }
    }

    private var crtWaitCount  = 0
    private var dispWaitCount = 0

    // ════════════════════════════════════════════
    // STEP 3 — M5 ENTRY CONFIRMATION (CHoCH + FVG)
    // ════════════════════════════════════════════

    private fun checkM5Entry(m5: List<Candle>, balance: Double) {
        if (m5.size < 5) return
        val fvg     = crtSetup.displaceFVG ?: return
        val current = m5.first().close

        val inFVG = current in fvg.bottom..fvg.top

        when (h4Bias) {
            Bias.BULL -> {
                val choch = m5[2].close < m5[2].open &&   // bar 2 bearish
                            m5[1].close > m5[1].open &&   // bar 1 bullish (CHoCH)
                            m5[1].close > m5[2].high      // closes above prior high
                if (inFVG && choch) buildAndEmitSignal(TradeDirection.BUY, balance)
            }
            Bias.BEAR -> {
                val choch = m5[2].close > m5[2].open &&   // bar 2 bullish
                            m5[1].close < m5[1].open &&   // bar 1 bearish (CHoCH)
                            m5[1].close < m5[2].low       // closes below prior low
                if (inFVG && choch) buildAndEmitSignal(TradeDirection.SELL, balance)
            }
            Bias.NONE -> {}
        }
    }

    // ════════════════════════════════════════════
    // STEP 4 — BUILD SIGNAL + RISK SIZE
    // ════════════════════════════════════════════

    private fun buildAndEmitSignal(dir: TradeDirection, balance: Double) {
        val fvg = crtSetup.displaceFVG ?: return
        val entry = fvg.mid

        val sl = when (dir) {
            TradeDirection.BUY  -> crtSetup.manipWick - config.slBufferPoints * 0.01
            TradeDirection.SELL -> crtSetup.manipWick + config.slBufferPoints * 0.01
        }
        val tp1 = crtSetup.refMid
        val tp2 = if (dir == TradeDirection.BUY) crtSetup.refHigh else crtSetup.refLow
        val tp3 = h1FVG?.let { if (dir == TradeDirection.BUY) it.top else it.bottom }
                  ?: tp2 + (tp2 - tp1)

        val slDist   = abs(entry - sl)
        val tp2Dist  = abs(tp2 - entry)
        val rr       = if (slDist > 0) tp2Dist / slDist else 0.0

        if (rr < config.minRR) {
            log(LogLevel.WARNING, "Signal skipped: R:R ${"%.2f".format(rr)} < min ${config.minRR}")
            return
        }

        // Position sizing
        val riskAmt = balance * (config.riskPercent / 100.0)
        val pipVal  = 1.0 // For XAUUSD 1 pip = ~$1 per 0.01 lot; adjust per broker
        val lotSize = if (slDist > 0) riskAmt / (slDist * 100 * pipVal) else 0.01
        val clampedLot = lotSize.coerceIn(0.01, 100.0).let {
            (Math.round(it / 0.01) * 0.01)
        }

        val signal = TradeSignal(
            direction   = dir,
            orderType   = if (dir == TradeDirection.BUY) OrderType.BUY_LIMIT else OrderType.SELL_LIMIT,
            entryPrice  = entry,
            sl          = sl,
            tp1         = tp1,
            tp2         = tp2,
            tp3         = tp3,
            lotSize     = clampedLot,
            riskReward  = rr,
            confidence  = calculateConfidence(),
            reason      = "SMC+CRT: ${h4Bias.name} bias | ${getCurrentSession().name} session",
            crtSetup    = crtSetup,
            smcAnalysis = SMCAnalysis(h4Bias = h4Bias)
        )

        log(LogLevel.TRADE, "⚡ SIGNAL: $dir @ ${"%.2f".format(entry)} | " +
                "SL:${"%.2f".format(sl)} TP1:${"%.2f".format(tp1)} TP2:${"%.2f".format(tp2)} " +
                "R:R ${"%.2f".format(rr)} | Lots: $clampedLot")

        onSignal(signal)
        crtSetup = crtSetup.copy(state = CRTState.COMPLETE)
        sessionTradeCount++
    }

    private fun calculateConfidence(): Float {
        var score = 0f
        if (h1OB != null)  score += 0.25f   // H1 OB aligned
        if (h1FVG != null) score += 0.20f   // H1 FVG present
        if (h4Bias != Bias.NONE) score += 0.30f // Clear H4 bias
        score += when (getCurrentSession()) {
            SessionType.LONDON -> 0.25f
            SessionType.NY     -> 0.20f
            else               -> 0.05f
        }
        return score.coerceIn(0f, 1f)
    }

    // ════════════════════════════════════════════
    // STRUCTURE DETECTION HELPERS
    // ════════════════════════════════════════════

    private fun findOrderBlock(candles: List<Candle>, bias: Bias, tf: String): OrderBlock? {
        for (i in 1 until candles.size - 1) {
            val c    = candles[i]
            val next = candles[i - 1]
            when (bias) {
                Bias.BULL -> {
                    if (c.close < c.open && next.close > c.high) { // Bearish OB before BOS
                        return OrderBlock(c.high, c.low, isBullish = true, timeframe = tf, time = c.time)
                    }
                }
                Bias.BEAR -> {
                    if (c.close > c.open && next.close < c.low) {  // Bullish OB before BOS
                        return OrderBlock(c.high, c.low, isBullish = false, timeframe = tf, time = c.time)
                    }
                }
                Bias.NONE -> {}
            }
        }
        return null
    }

    private fun findFVG(candles: List<Candle>, bias: Bias, tf: String): FairValueGap? {
        for (i in 2 until candles.size) {
            val c1 = candles[i]     // oldest
            val c3 = candles[i - 2] // newest
            when (bias) {
                Bias.BULL -> {
                    if (c3.low > c1.high) { // Bullish FVG: gap up
                        val gap = c3.low - c1.high
                        if (gap > 0.5) return FairValueGap(c3.low, c1.high, isBullish = true, timeframe = tf)
                    }
                }
                Bias.BEAR -> {
                    if (c3.high < c1.low) { // Bearish FVG: gap down
                        val gap = c1.low - c3.high
                        if (gap > 0.5) return FairValueGap(c1.low, c3.high, isBullish = false, timeframe = tf)
                    }
                }
                Bias.NONE -> {}
            }
        }
        return null
    }

    private fun findSwingHigh(candles: List<Candle>, strength: Int): Int {
        for (i in strength until candles.size - strength) {
            val c = candles[i]
            val isSwing = (0 until strength).all { j ->
                candles[i - j].high <= c.high && candles[i + j].high <= c.high
            }
            if (isSwing) return i
        }
        return 0
    }

    private fun findSwingLow(candles: List<Candle>, strength: Int): Int {
        for (i in strength until candles.size - strength) {
            val c = candles[i]
            val isSwing = (0 until strength).all { j ->
                candles[i - j].low >= c.low && candles[i + j].low >= c.low
            }
            if (isSwing) return i
        }
        return 0
    }

    // ════════════════════════════════════════════
    // SESSION & DAILY MANAGEMENT
    // ════════════════════════════════════════════

    fun isSessionActive(): Boolean {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"))
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        return (hour in 2..4) || (hour in 8..9) // London or NY
    }

    private fun getCurrentSession(): SessionType {
        val cal  = Calendar.getInstance(TimeZone.getTimeZone("America/New_York"))
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        return when {
            hour in 2..4   -> SessionType.LONDON
            hour in 8..9   -> SessionType.NY
            hour >= 20 || hour < 1 -> SessionType.ASIAN
            else -> SessionType.NONE
        }
    }

    private fun checkDailyReset(balance: Double) {
        val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val lastDay = Calendar.getInstance().also { it.timeInMillis = lastDayStart }
            .get(Calendar.DAY_OF_YEAR)
        if (today != lastDay) {
            sessionTradeCount = 0
            consecLosses      = 0
            isPaused          = false
            dayStartBalance   = balance
            lastDayStart      = System.currentTimeMillis()
            resetCRT()
            log(LogLevel.INFO, "📅 Daily reset | Balance: $balance")
        }
    }

    fun onTradeClosed(profit: Double) {
        if (profit < 0) {
            consecLosses++
            if (consecLosses >= config.maxConsecLosses) {
                isPaused = true
                log(LogLevel.WARNING, "⛔ PAUSED: ${config.maxConsecLosses} consecutive losses")
            }
        } else {
            consecLosses = 0
        }
    }

    // ════════════════════════════════════════════
    // UTILS
    // ════════════════════════════════════════════

    private fun resetCRT() {
        crtSetup      = CRTSetup()
        crtWaitCount  = 0
        dispWaitCount = 0
    }

    private fun log(level: LogLevel, msg: String) = onLog(level, msg)

    fun getEAState(): EAState = EAState(
        isRunning      = !isPaused,
        isPaused       = isPaused,
        sessionTrades  = sessionTradeCount,
        consecLosses   = consecLosses,
        status         = if (isPaused) "PAUSED" else "CRT: ${crtSetup.state.name}"
    )
}
