package com.razorEA.bot.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// ════════════════════════════════════════════
// ACCOUNT & CONNECTION
// ════════════════════════════════════════════

enum class Platform { MT4, MT5 }
enum class AccountType { DEMO, LIVE }
enum class ConnectionStatus { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

@Parcelize
data class BrokerAccount(
    val id: String = java.util.UUID.randomUUID().toString(),
    val platform: Platform = Platform.MT5,
    val broker: String = "",
    val server: String = "",
    val login: String = "",
    val passwordHash: String = "",
    val accountType: AccountType = AccountType.DEMO,
    val isActive: Boolean = false,
    val alias: String = ""
) : Parcelable

data class ConnectionState(
    val status: ConnectionStatus = ConnectionStatus.DISCONNECTED,
    val account: BrokerAccount? = null,
    val balance: Double = 0.0,
    val equity: Double = 0.0,
    val margin: Double = 0.0,
    val freeMargin: Double = 0.0,
    val leverage: Int = 0,
    val currency: String = "USD",
    val ping: Long = 0L,
    val errorMsg: String = ""
)

// ════════════════════════════════════════════
// MARKET DATA
// ════════════════════════════════════════════

data class Tick(
    val symbol: String,
    val bid: Double,
    val ask: Double,
    val time: Long = System.currentTimeMillis(),
    val spread: Int = ((ask - bid) * 10).toInt()
)

data class Candle(
    val time: Long,
    val open: Double,
    val high: Double,
    val close: Double,
    val low: Double,
    val volume: Long = 0,
    val timeframe: String = "M15"
)

data class PriceLevel(
    val price: Double,
    val label: String,
    val type: LevelType
)

enum class LevelType { OB_BULL, OB_BEAR, FVG_BULL, FVG_BEAR, CRT_MID, CRT_HIGH, CRT_LOW, EQUILIBRIUM }

// ════════════════════════════════════════════
// SMC ANALYSIS RESULTS
// ════════════════════════════════════════════

enum class Bias { NONE, BULL, BEAR }

data class OrderBlock(
    val high: Double,
    val low: Double,
    val mid: Double = (high + low) / 2,
    val isBullish: Boolean,
    val timeframe: String,
    val time: Long = System.currentTimeMillis(),
    val valid: Boolean = true
)

data class FairValueGap(
    val top: Double,
    val bottom: Double,
    val mid: Double = (top + bottom) / 2,
    val isBullish: Boolean,
    val timeframe: String,
    val time: Long = System.currentTimeMillis(),
    val valid: Boolean = true
)

data class SMCAnalysis(
    val h4Bias: Bias = Bias.NONE,
    val h1Bias: Bias = Bias.NONE,
    val h4OB: OrderBlock? = null,
    val h1OB: OrderBlock? = null,
    val h4FVG: FairValueGap? = null,
    val h1FVG: FairValueGap? = null,
    val equilibrium: Double = 0.0,
    val inDiscount: Boolean = false,
    val inPremium: Boolean = false
)

// ════════════════════════════════════════════
// CRT MODEL
// ════════════════════════════════════════════

enum class CRTState { WAIT_REF, WAIT_MANIP, WAIT_DISPLACE, WAIT_ENTRY, COMPLETE }

data class CRTSetup(
    val refHigh: Double = 0.0,
    val refLow: Double = 0.0,
    val refMid: Double = 0.0,
    val manipWick: Double = 0.0,
    val displaceFVG: FairValueGap? = null,
    val state: CRTState = CRTState.WAIT_REF,
    val valid: Boolean = false,
    val session: SessionType = SessionType.NONE
)

enum class SessionType { NONE, ASIAN, LONDON, NY }

// ════════════════════════════════════════════
// TRADING
// ════════════════════════════════════════════

enum class TradeDirection { BUY, SELL }
enum class TradeStatus { PENDING, OPEN, CLOSED_TP, CLOSED_SL, CLOSED_MANUAL, CANCELLED }
enum class OrderType { MARKET, BUY_LIMIT, SELL_LIMIT, BUY_STOP, SELL_STOP }

data class TradeSignal(
    val direction: TradeDirection,
    val orderType: OrderType,
    val entryPrice: Double,
    val sl: Double,
    val tp1: Double,
    val tp2: Double,
    val tp3: Double,
    val lotSize: Double,
    val riskReward: Double,
    val confidence: Float,          // 0.0 – 1.0
    val reason: String,
    val crtSetup: CRTSetup,
    val smcAnalysis: SMCAnalysis,
    val timestamp: Long = System.currentTimeMillis()
)

data class TradeRecord(
    val id: String = java.util.UUID.randomUUID().toString(),
    val ticket: Long = 0,
    val symbol: String = "XAUUSD",
    val direction: TradeDirection = TradeDirection.BUY,
    val orderType: OrderType = OrderType.BUY_LIMIT,
    val entryPrice: Double = 0.0,
    val sl: Double = 0.0,
    val tp1: Double = 0.0,
    val tp2: Double = 0.0,
    val tp3: Double = 0.0,
    val currentSL: Double = 0.0,
    val lots: Double = 0.0,
    val openTime: Long = System.currentTimeMillis(),
    val closeTime: Long = 0,
    val closePrice: Double = 0.0,
    val profit: Double = 0.0,
    val status: TradeStatus = TradeStatus.PENDING,
    val rr: Double = 0.0,
    val isPartialClosed: Boolean = false
)

// ════════════════════════════════════════════
// RISK & EA STATE
// ════════════════════════════════════════════

data class RiskConfig(
    val riskPercent: Double = 1.0,
    val maxDailyDD: Double = 3.0,
    val maxConsecLosses: Int = 3,
    val minRR: Double = 2.0,
    val maxTradesPerSession: Int = 2,
    val maxSpread: Int = 30,
    val slBufferPoints: Int = 150,
    val tp1PartialPct: Double = 50.0,
    val moveToBreakeven: Boolean = true,
    val trailAfterTP2: Boolean = true
)

data class EAState(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val pauseReason: String = "",
    val sessionTrades: Int = 0,
    val consecLosses: Int = 0,
    val dailyPnL: Double = 0.0,
    val dayStartBalance: Double = 0.0,
    val totalTrades: Int = 0,
    val winRate: Float = 0f,
    val status: String = "Initializing..."
)

// ════════════════════════════════════════════
// LICENSE
// ════════════════════════════════════════════

data class License(
    val key: String,
    val botName: String,
    val maskedKey: String,
    val expiryDate: String,
    val isActive: Boolean = true
)

// ════════════════════════════════════════════
// LOG
// ════════════════════════════════════════════

enum class LogLevel { DEBUG, INFO, WARNING, ERROR, TRADE }

data class LogEntry(
    val level: LogLevel,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)
