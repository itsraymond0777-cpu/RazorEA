package com.razorEA.bot.service

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.razorEA.bot.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.*
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * MT5ConnectionService
 *
 * Connects to MetaTrader 5 / MetaTrader 4 via:
 *  1. MetaApi cloud REST+WebSocket (recommended — free tier)
 *  2. Direct WebSocket bridge (requires local VPS with bridge script)
 *
 * Protocol flow:
 *   Authenticate → Subscribe to ticks → Stream candles → Execute orders
 */
class MT5ConnectionService {

    companion object {
        private const val TAG = "MT5Connection"
        // MetaApi endpoints (free tier — metaapi.cloud)
        private const val META_API_BASE   = "https://mt-client-api-v1.london.agiliumtrade.ai"
        private const val META_API_WS     = "wss://mt-client-api-v1.london.agiliumtrade.ai"
        // Fallback: direct VPS bridge (user configures)
        private var VPS_BRIDGE_WS         = "ws://YOUR_VPS_IP:8765"

        // Singleton
        val instance by lazy { MT5ConnectionService() }
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val gson  = Gson()
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private var metaApiToken: String = ""
    private var accountId: String = ""
    private var currentAccount: BrokerAccount? = null

    // ── Public state flows ──────────────────────────────────────────
    private val _connectionState = MutableStateFlow(ConnectionState())
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _tickFlow = MutableStateFlow(Tick("XAUUSD", 0.0, 0.0))
    val tickFlow: StateFlow<Tick> = _tickFlow

    private val _candlesH4  = MutableStateFlow<List<Candle>>(emptyList())
    private val _candlesH1  = MutableStateFlow<List<Candle>>(emptyList())
    private val _candlesM15 = MutableStateFlow<List<Candle>>(emptyList())
    private val _candlesM5  = MutableStateFlow<List<Candle>>(emptyList())

    val candlesH4:  StateFlow<List<Candle>> = _candlesH4
    val candlesH1:  StateFlow<List<Candle>> = _candlesH1
    val candlesM15: StateFlow<List<Candle>> = _candlesM15
    val candlesM5:  StateFlow<List<Candle>> = _candlesM5

    private val _openTrades = MutableStateFlow<List<TradeRecord>>(emptyList())
    val openTrades: StateFlow<List<TradeRecord>> = _openTrades

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs

    // ════════════════════════════════════════════
    // CONNECT
    // ════════════════════════════════════════════

    fun connect(account: BrokerAccount, metaApiKey: String = "", vpsUrl: String = "") {
        currentAccount = account
        if (metaApiKey.isNotEmpty()) {
            metaApiToken = metaApiKey
            connectViaMetaApi(account)
        } else {
            if (vpsUrl.isNotEmpty()) VPS_BRIDGE_WS = vpsUrl
            connectViaVPSBridge(account)
        }
    }

    // ─── MetaApi cloud connection ────────────────────────────────────
    private fun connectViaMetaApi(account: BrokerAccount) {
        updateStatus(ConnectionStatus.CONNECTING)
        log(LogLevel.INFO, "Connecting to MetaApi for ${account.broker} / ${account.login}")

        scope.launch {
            try {
                // Step 1: authenticate account with MetaApi
                val authResult = authenticateMetaApi(account)
                if (!authResult) {
                    updateStatus(ConnectionStatus.ERROR, "MetaApi authentication failed")
                    return@launch
                }
                // Step 2: open WebSocket
                openWebSocket("$META_API_WS/ws/v1?auth-token=$metaApiToken&accountId=$accountId")
            } catch (e: Exception) {
                updateStatus(ConnectionStatus.ERROR, e.message ?: "Unknown error")
                log(LogLevel.ERROR, "MetaApi connect failed: ${e.message}")
            }
        }
    }

    private suspend fun authenticateMetaApi(account: BrokerAccount): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val body = gson.toJson(mapOf(
                    "login"    to account.login,
                    "password" to account.passwordHash,
                    "serverName" to account.server,
                    "platform"   to if (account.platform == Platform.MT5) "mt5" else "mt4"
                ))
                val req = Request.Builder()
                    .url("$META_API_BASE/users/current/accounts")
                    .addHeader("auth-token", metaApiToken)
                    .post(RequestBody.create(
                        okhttp3.MediaType.parse("application/json"), body))
                    .build()
                val resp = httpClient.newCall(req).execute()
                if (resp.isSuccessful) {
                    val json = gson.fromJson(resp.body()?.string(), JsonObject::class.java)
                    accountId = json.get("id")?.asString ?: ""
                    log(LogLevel.INFO, "MetaApi accountId: $accountId")
                    true
                } else {
                    false
                }
            } catch (e: Exception) {
                log(LogLevel.ERROR, "Auth error: ${e.message}")
                false
            }
        }
    }

    // ─── VPS Bridge connection (local Python/Node bridge) ────────────
    private fun connectViaVPSBridge(account: BrokerAccount) {
        updateStatus(ConnectionStatus.CONNECTING)
        log(LogLevel.INFO, "Connecting via VPS bridge: $VPS_BRIDGE_WS")
        scope.launch {
            val authPayload = gson.toJson(mapOf(
                "type"     to "auth",
                "broker"   to account.broker,
                "server"   to account.server,
                "login"    to account.login,
                "password" to account.passwordHash,
                "platform" to account.platform.name
            ))
            openWebSocket(VPS_BRIDGE_WS, authPayload)
        }
    }

    // ─── WebSocket core ──────────────────────────────────────────────
    private fun openWebSocket(url: String, initialMsg: String? = null) {
        val request = Request.Builder().url(url).build()
        webSocket = httpClient.newWebSocket(request, object : WebSocketListener() {

            override fun onOpen(ws: WebSocket, response: Response) {
                log(LogLevel.INFO, "WebSocket connected")
                updateStatus(ConnectionStatus.CONNECTED)
                initialMsg?.let { ws.send(it) }
                // Subscribe to XAUUSD ticks & candles
                ws.send(gson.toJson(mapOf("type" to "subscribe", "symbol" to "XAUUSD")))
                fetchCandles(ws)
                startHeartbeat(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleMessage(text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                log(LogLevel.ERROR, "WebSocket failure: ${t.message}")
                updateStatus(ConnectionStatus.ERROR, t.message ?: "Connection lost")
                scheduleReconnect()
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                log(LogLevel.INFO, "WebSocket closed: $reason")
                updateStatus(ConnectionStatus.DISCONNECTED)
            }
        })
    }

    private fun handleMessage(raw: String) {
        try {
            val json = gson.fromJson(raw, JsonObject::class.java)
            when (json.get("type")?.asString) {
                "tick" -> {
                    val tick = Tick(
                        symbol = json.get("symbol").asString,
                        bid    = json.get("bid").asDouble,
                        ask    = json.get("ask").asDouble,
                        time   = json.get("time")?.asLong ?: System.currentTimeMillis()
                    )
                    _tickFlow.value = tick
                }
                "candles" -> {
                    val tf   = json.get("timeframe").asString
                    val list = json.get("candles").asJsonArray.map { c ->
                        val o = c.asJsonObject
                        Candle(
                            time  = o.get("time").asLong,
                            open  = o.get("open").asDouble,
                            high  = o.get("high").asDouble,
                            low   = o.get("low").asDouble,
                            close = o.get("close").asDouble,
                            timeframe = tf
                        )
                    }
                    when (tf) {
                        "H4"  -> _candlesH4.value  = list
                        "H1"  -> _candlesH1.value  = list
                        "M15" -> _candlesM15.value = list
                        "M5"  -> _candlesM5.value  = list
                    }
                }
                "account" -> {
                    val balance    = json.get("balance")?.asDouble ?: 0.0
                    val equity     = json.get("equity")?.asDouble  ?: 0.0
                    val margin     = json.get("margin")?.asDouble  ?: 0.0
                    val freeMargin = json.get("freeMargin")?.asDouble ?: 0.0
                    val leverage   = json.get("leverage")?.asInt ?: 0
                    val currency   = json.get("currency")?.asString ?: "USD"
                    _connectionState.value = _connectionState.value.copy(
                        balance    = balance,
                        equity     = equity,
                        margin     = margin,
                        freeMargin = freeMargin,
                        leverage   = leverage,
                        currency   = currency
                    )
                }
                "trade" -> {
                    // Open trade update
                    val trade = parseTradeRecord(json)
                    val current = _openTrades.value.toMutableList()
                    val idx = current.indexOfFirst { it.ticket == trade.ticket }
                    if (idx >= 0) current[idx] = trade else current.add(trade)
                    _openTrades.value = current
                }
                "heartbeat" -> { /* ignore */ }
                "error" -> {
                    log(LogLevel.ERROR, json.get("message")?.asString ?: "Server error")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Parse error: ${e.message}")
        }
    }

    // ════════════════════════════════════════════
    // TRADE EXECUTION
    // ════════════════════════════════════════════

    fun placeOrder(signal: TradeSignal, callback: (Boolean, String) -> Unit) {
        val ws = webSocket
        if (ws == null) { callback(false, "Not connected"); return }

        val order = mapOf(
            "type"       to "order",
            "action"     to if (signal.direction == TradeDirection.BUY) "BUY_LIMIT" else "SELL_LIMIT",
            "symbol"     to "XAUUSD",
            "volume"     to signal.lotSize,
            "price"      to signal.entryPrice,
            "sl"         to signal.sl,
            "tp"         to signal.tp1,
            "comment"    to "RazorEA|TP2=${signal.tp2}|TP3=${signal.tp3}",
            "magic"      to 20250101
        )
        val sent = ws.send(gson.toJson(order))
        if (sent) {
            log(LogLevel.TRADE, "Order sent: ${signal.direction} @ ${signal.entryPrice} " +
                    "SL:${signal.sl} TP1:${signal.tp1}")
            callback(true, "Order submitted")
        } else {
            callback(false, "Failed to send order")
        }
    }

    fun closePosition(ticket: Long) {
        webSocket?.send(gson.toJson(mapOf("type" to "close", "ticket" to ticket)))
        log(LogLevel.TRADE, "Close request sent for ticket $ticket")
    }

    fun modifyOrder(ticket: Long, sl: Double, tp: Double) {
        webSocket?.send(gson.toJson(mapOf(
            "type"   to "modify",
            "ticket" to ticket,
            "sl"     to sl,
            "tp"     to tp
        )))
    }

    // ════════════════════════════════════════════
    // HELPERS
    // ════════════════════════════════════════════

    private fun fetchCandles(ws: WebSocket) {
        listOf("H4", "H1", "M15", "M5").forEach { tf ->
            ws.send(gson.toJson(mapOf(
                "type"      to "getCandles",
                "symbol"    to "XAUUSD",
                "timeframe" to tf,
                "count"     to 100
            )))
        }
    }

    private fun startHeartbeat(ws: WebSocket) {
        scope.launch {
            while (isActive) {
                delay(30_000)
                ws.send(gson.toJson(mapOf("type" to "heartbeat")))
            }
        }
    }

    private fun scheduleReconnect() {
        scope.launch {
            delay(5_000)
            currentAccount?.let {
                log(LogLevel.INFO, "Reconnecting...")
                connect(it, metaApiToken)
            }
        }
    }

    private fun updateStatus(status: ConnectionStatus, error: String = "") {
        _connectionState.value = _connectionState.value.copy(
            status   = status,
            errorMsg = error,
            account  = currentAccount
        )
    }

    private fun parseTradeRecord(json: JsonObject): TradeRecord {
        return TradeRecord(
            ticket      = json.get("ticket")?.asLong ?: 0,
            direction   = if (json.get("type")?.asString == "BUY") TradeDirection.BUY else TradeDirection.SELL,
            entryPrice  = json.get("openPrice")?.asDouble ?: 0.0,
            sl          = json.get("sl")?.asDouble ?: 0.0,
            tp1         = json.get("tp")?.asDouble ?: 0.0,
            lots        = json.get("volume")?.asDouble ?: 0.0,
            profit      = json.get("profit")?.asDouble ?: 0.0,
            status      = TradeStatus.OPEN
        )
    }

    fun log(level: LogLevel, message: String) {
        val entry = LogEntry(level, message)
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 500) current.removeLastOrNull()
        _logs.value = current
        Log.d(TAG, "[${level.name}] $message")
    }

    fun disconnect() {
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        updateStatus(ConnectionStatus.DISCONNECTED)
        scope.cancel()
    }
}
