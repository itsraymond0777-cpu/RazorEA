package com.razorEA.bot.service

import android.app.*
import android.content.Intent
import android.graphics.*
import android.os.*
import android.view.*
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.core.app.NotificationCompat
import com.razorEA.bot.R
import com.razorEA.bot.RazorEAApp
import com.razorEA.bot.model.*
import com.razorEA.bot.network.MT5ConnectionService
import com.razorEA.bot.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * OverlayService
 *
 * Displays a draggable floating widget over ALL other apps.
 * Shows: live bid/ask, EA status, session, PnL, and quick controls.
 * Requires SYSTEM_ALERT_WINDOW permission.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var collapsed = false
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Views
    private var tvBid: TextView?     = null
    private var tvAsk: TextView?     = null
    private var tvSpread: TextView?  = null
    private var tvStatus: TextView?  = null
    private var tvSession: TextView? = null
    private var tvPnL: TextView?     = null
    private var tvBias: TextView?    = null
    private var tvCRT: TextView?     = null
    private var btnToggle: ImageButton? = null
    private var btnClose: ImageButton?  = null
    private var btnTrade: Button?       = null
    private var dotIndicator: View?     = null
    private var cardContent: View?      = null
    private var ivLogo: ImageView?      = null

    // Drag tracking
    private var initX = 0; private var initY = 0
    private var initTX = 0f; private var initTY = 0f
    private var isDragging = false

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        createOverlay()
        observeData()
    }

    // ════════════════════════════════════════════
    // NOTIFICATION (required for foreground service)
    // ════════════════════════════════════════════

    private fun startForegroundNotification() {
        val intent    = Intent(this, MainActivity::class.java)
        val pending   = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val notification = NotificationCompat.Builder(this, RazorEAApp.CHANNEL_OVERLAY)
            .setContentTitle("Razor EA — Overlay Active")
            .setContentText("Trading bot is running in the background")
            .setSmallIcon(R.drawable.ic_razor_notif)
            .setContentIntent(pending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    // ════════════════════════════════════════════
    // CREATE OVERLAY WINDOW
    // ════════════════════════════════════════════

    private fun createOverlay() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater  = LayoutInflater.from(this)
        overlayView   = inflater.inflate(R.layout.overlay_widget, null)

        // WindowManager layout params
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16; y = 200
        }

        windowManager.addView(overlayView, params)
        bindViews()
        setupDrag(params)
        setupButtons()
    }

    private fun bindViews() {
        overlayView?.apply {
            tvBid       = findViewById(R.id.overlay_bid)
            tvAsk       = findViewById(R.id.overlay_ask)
            tvSpread    = findViewById(R.id.overlay_spread)
            tvStatus    = findViewById(R.id.overlay_status)
            tvSession   = findViewById(R.id.overlay_session)
            tvPnL       = findViewById(R.id.overlay_pnl)
            tvBias      = findViewById(R.id.overlay_bias)
            tvCRT       = findViewById(R.id.overlay_crt)
            btnToggle   = findViewById(R.id.overlay_btn_toggle)
            btnClose    = findViewById(R.id.overlay_btn_close)
            btnTrade    = findViewById(R.id.overlay_btn_trade)
            dotIndicator = findViewById(R.id.overlay_dot)
            cardContent = findViewById(R.id.overlay_content)
            ivLogo      = findViewById(R.id.overlay_logo)
        }
    }

    // ════════════════════════════════════════════
    // DRAG SUPPORT
    // ════════════════════════════════════════════

    private fun setupDrag(params: WindowManager.LayoutParams) {
        val handle = overlayView?.findViewById<View>(R.id.overlay_handle) ?: return
        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX  = params.x; initY  = params.y
                    initTX = event.rawX; initTY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initTX).toInt()
                    val dy = (event.rawY - initTY).toInt()
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) isDragging = true
                    params.x = initX + dx
                    params.y = initY + dy
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) toggleExpand()
                    true
                }
                else -> false
            }
        }
    }

    // ════════════════════════════════════════════
    // BUTTON ACTIONS
    // ════════════════════════════════════════════

    private fun setupButtons() {
        btnToggle?.setOnClickListener { toggleExpand() }

        btnClose?.setOnClickListener {
            stopSelf()
        }

        btnTrade?.setOnClickListener {
            // Open app for full trade control
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra("tab", "trading")
            }
            startActivity(intent)
        }
    }

    private fun toggleExpand() {
        collapsed = !collapsed
        cardContent?.visibility = if (collapsed) View.GONE else View.VISIBLE
        btnToggle?.setImageResource(
            if (collapsed) R.drawable.ic_expand else R.drawable.ic_collapse
        )
    }

    // ════════════════════════════════════════════
    // DATA OBSERVATION
    // ════════════════════════════════════════════

    private fun observeData() {
        val conn = MT5ConnectionService.instance

        // Live tick → update bid/ask
        scope.launch {
            conn.tickFlow.collectLatest { tick ->
                if (tick.bid == 0.0) return@collectLatest
                tvBid?.text    = "%.2f".format(tick.bid)
                tvAsk?.text    = "%.2f".format(tick.ask)
                tvSpread?.text = "${tick.spread} pts"
                flashPriceChange(tick.bid)
            }
        }

        // Connection state → status dot & account info
        scope.launch {
            conn.connectionState.collectLatest { state ->
                updateConnectionUI(state)
            }
        }
    }

    private fun flashPriceChange(price: Double) {
        // Animate a brief flash on price update
        tvBid?.animate()?.alpha(0.4f)?.setDuration(80)?.withEndAction {
            tvBid?.animate()?.alpha(1f)?.setDuration(80)?.start()
        }?.start()
    }

    private fun updateConnectionUI(state: ConnectionState) {
        when (state.status) {
            ConnectionStatus.CONNECTED -> {
                dotIndicator?.setBackgroundResource(R.drawable.dot_green)
                tvStatus?.text = "● LIVE"
                tvStatus?.setTextColor(Color.parseColor("#00FF88"))
                val pnl = state.equity - state.balance
                tvPnL?.text = "${if (pnl >= 0) "+" else ""}${"%.2f".format(pnl)}"
                tvPnL?.setTextColor(if (pnl >= 0) Color.parseColor("#00FF88") else Color.parseColor("#FF4444"))
            }
            ConnectionStatus.CONNECTING -> {
                dotIndicator?.setBackgroundResource(R.drawable.dot_yellow)
                tvStatus?.text = "● CONNECTING"
                tvStatus?.setTextColor(Color.YELLOW)
            }
            ConnectionStatus.DISCONNECTED -> {
                dotIndicator?.setBackgroundResource(R.drawable.dot_gray)
                tvStatus?.text = "● OFFLINE"
                tvStatus?.setTextColor(Color.GRAY)
            }
            ConnectionStatus.ERROR -> {
                dotIndicator?.setBackgroundResource(R.drawable.dot_red)
                tvStatus?.text = "● ERROR"
                tvStatus?.setTextColor(Color.RED)
            }
        }
    }

    fun updateEAState(state: EAState, bias: Bias) {
        tvCRT?.text = state.status
        tvBias?.text = when (bias) {
            Bias.BULL -> "▲ BULL"
            Bias.BEAR -> "▼ BEAR"
            Bias.NONE -> "─ NONE"
        }
        tvBias?.setTextColor(when (bias) {
            Bias.BULL -> Color.parseColor("#00FF88")
            Bias.BEAR -> Color.parseColor("#FF4444")
            Bias.NONE -> Color.GRAY
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        overlayView?.let { windowManager.removeView(it) }
        overlayView = null
    }

    companion object {
        const val NOTIF_ID = 1001
    }
}
