package com.razorEA.bot.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * RazorAccessibilityService
 *
 * Grants the EA full accessibility to:
 *  - Monitor screen changes
 *  - Detect when MetaTrader is in foreground
 *  - Auto-relay notifications
 */
class RazorAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            packageNames = null // Monitor all apps
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        // Can be extended to detect MT5 app state, read notifications, etc.
        when (event.eventType) {
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                // Handle MT5/broker notifications if needed
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // Detect foreground app changes
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
    }
}
