package com.razorEA.bot.service

import android.app.*
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import com.razorEA.bot.R
import com.razorEA.bot.RazorEAApp
import com.razorEA.bot.engine.TradingEngine
import com.razorEA.bot.model.*
import com.razorEA.bot.network.MT5ConnectionService
import com.razorEA.bot.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class TradingService : Service() {

    private val scope  = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val conn   = MT5ConnectionService.instance
    private lateinit var engine: TradingEngine

    private var lastM15BarTime = 0L
    private var lastM5BarTime  = 0L

    private val _eaState = MutableStateFlow(EAState())
    val eaState: StateFlow<EAState> = _eaState

    private val _signals = MutableStateFlow<TradeSignal?>(null)
    val signals: StateFlow<TradeSignal?> = _signals

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification("Razor EA — Initializing"))

        engine = TradingEngine(
            config   = loadRiskConfig(),
            onSignal = ::handleSignal,
            onLog    = { lvl, msg -> conn.log(lvl, msg) }
        )

        observeMarketData()
    }

    private fun observeMarketData() {
        scope.launch {
            // Combine all timeframe candles and trigger engine on new M15 bar
            combine(
                conn.candlesH4,
                conn.candlesH1,
                conn.candlesM15,
                conn.candlesM5,
                conn.connectionState
            ) { h4, h1, m15, m5, state ->
                Quintuple(h4, h1, m15, m5, state)
            }.collectLatest { (h4, h1, m15, m5, state) ->
                if (state.status != ConnectionStatus.CONNECTED) return@collectLatest
                if (m15.isEmpty()) return@collectLatest

                val currentM15 = m15.firstOrNull()?.time ?: return@collectLatest
                if (currentM15 != lastM15BarTime) {
                    lastM15BarTime = currentM15
                    engine.onNewBar(h4, h1, m15, m5, state.balance, state.equity)
                    _eaState.value = engine.getEAState()
                    updateNotification(_eaState.value.status)
                }
            }
        }
    }

    private fun handleSignal(signal: TradeSignal) {
        conn.log(LogLevel.TRADE, "Signal received: ${signal.direction} @ ${signal.entryPrice}")
        _signals.value = signal

        // Auto-execute if configured
        if (isAutoTradeEnabled()) {
            conn.placeOrder(signal) { success, msg ->
                conn.log(
                    if (success) LogLevel.TRADE else LogLevel.ERROR,
                    "Order ${if (success) "placed" else "failed"}: $msg"
                )
                updateNotification(if (success) "✅ Trade placed: ${signal.direction}" else "❌ Order failed: $msg")
            }
        }
    }

    fun startEA()  { _eaState.value = _eaState.value.copy(isRunning = true) }
    fun stopEA()   { _eaState.value = _eaState.value.copy(isRunning = false) }
    fun pauseEA()  { _eaState.value = _eaState.value.copy(isPaused = true) }
    fun resumeEA() { _eaState.value = _eaState.value.copy(isPaused = false) }

    private fun isAutoTradeEnabled(): Boolean {
        return getSharedPreferences("razor_config", MODE_PRIVATE)
            .getBoolean("auto_trade", true)
    }

    private fun loadRiskConfig(): RiskConfig {
        val prefs = getSharedPreferences("razor_config", MODE_PRIVATE)
        return RiskConfig(
            riskPercent         = prefs.getFloat("risk_pct", 1.0f).toDouble(),
            maxDailyDD          = prefs.getFloat("max_dd", 3.0f).toDouble(),
            maxConsecLosses     = prefs.getInt("max_losses", 3),
            minRR               = prefs.getFloat("min_rr", 2.0f).toDouble(),
            maxTradesPerSession = prefs.getInt("max_session_trades", 2),
            maxSpread           = prefs.getInt("max_spread", 30),
            slBufferPoints      = prefs.getInt("sl_buffer", 150),
            moveToBreakeven     = prefs.getBoolean("move_be", true),
            trailAfterTP2       = prefs.getBoolean("trail_tp2", true)
        )
    }

    private fun buildNotification(text: String): Notification {
        val intent  = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, RazorEAApp.CHANNEL_TRADING)
            .setContentTitle("⚔ Razor EA")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_razor_notif)
            .setContentIntent(intent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    companion object {
        const val NOTIF_ID = 1002

        // Binder for activity binding
        var instance: TradingService? = null
    }
}

// Kotlin doesn't have Quintuple, so define one
data class Quintuple<A,B,C,D,E>(val first: A, val second: B, val third: C,
                                  val fourth: D, val fifth: E)
