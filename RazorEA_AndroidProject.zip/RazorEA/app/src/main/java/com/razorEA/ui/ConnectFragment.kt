package com.razorEA.bot.ui

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.razorEA.bot.databinding.FragmentConnectBinding
import com.razorEA.bot.model.*
import com.razorEA.bot.network.MT5ConnectionService
import com.razorEA.bot.utils.SecurePrefs
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ConnectFragment : Fragment() {

    private var _binding: FragmentConnectBinding? = null
    private val binding get() = _binding!!
    private val conn = MT5ConnectionService.instance
    private var selectedPlatform = Platform.MT5

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = FragmentConnectBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupPlatformToggle()
        setupConnectButton()
        loadSavedAccount()
        observeConnectionState()
    }

    private fun setupPlatformToggle() {
        binding.togglePlatform.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                selectedPlatform = if (checkedId == binding.btnMT5.id) Platform.MT5 else Platform.MT4
            }
        }
        binding.togglePlatform.check(binding.btnMT5.id)
    }

    private fun setupConnectButton() {
        binding.btnConnect.setOnClickListener {
            val broker   = binding.etBroker.text.toString().trim()
            val server   = binding.etServer.text.toString().trim()
            val login    = binding.etLogin.text.toString().trim()
            val password = binding.etPassword.text.toString()

            if (broker.isEmpty() || server.isEmpty() || login.isEmpty() || password.isEmpty()) {
                Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val account = BrokerAccount(
                platform = selectedPlatform,
                broker   = broker,
                server   = server,
                login    = login,
                passwordHash = password,  // encrypted in SecurePrefs
                accountType  = AccountType.LIVE
            )

            // Save securely
            SecurePrefs.saveAccount(requireContext(), account)

            // Connect
            binding.btnConnect.isEnabled = false
            binding.btnConnect.text = "Connecting..."
            conn.connect(account)
        }

        binding.btnTestConnection.setOnClickListener {
            Toast.makeText(context, "Testing connection...", Toast.LENGTH_SHORT).show()
            // trigger a ping/test connect
        }
    }

    private fun loadSavedAccount() {
        SecurePrefs.loadAccount(requireContext())?.let { acc ->
            binding.etBroker.setText(acc.broker)
            binding.etServer.setText(acc.server)
            binding.etLogin.setText(acc.login)
            if (acc.platform == Platform.MT5) binding.togglePlatform.check(binding.btnMT5.id)
            else binding.togglePlatform.check(binding.btnMT4.id)
        }
    }

    private fun observeConnectionState() {
        viewLifecycleOwner.lifecycleScope.launch {
            conn.connectionState.collectLatest { state ->
                when (state.status) {
                    ConnectionStatus.CONNECTED -> {
                        binding.btnConnect.isEnabled = true
                        binding.btnConnect.text = "Connected ✓"
                        binding.tvConnectionInfo.text =
                            "Balance: ${"%.2f".format(state.balance)} ${state.currency} | " +
                            "Leverage: 1:${state.leverage}"
                        binding.tvConnectionInfo.visibility = View.VISIBLE
                    }
                    ConnectionStatus.CONNECTING -> {
                        binding.btnConnect.isEnabled = false
                        binding.btnConnect.text = "Connecting..."
                    }
                    ConnectionStatus.ERROR -> {
                        binding.btnConnect.isEnabled = true
                        binding.btnConnect.text = "Connect Account"
                        Toast.makeText(context, "Error: ${state.errorMsg}", Toast.LENGTH_LONG).show()
                    }
                    ConnectionStatus.DISCONNECTED -> {
                        binding.btnConnect.isEnabled = true
                        binding.btnConnect.text = "Connect Account"
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
