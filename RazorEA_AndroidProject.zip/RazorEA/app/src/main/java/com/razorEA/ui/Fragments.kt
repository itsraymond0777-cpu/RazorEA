package com.razorEA.bot.ui

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.razorEA.bot.R
import com.razorEA.bot.databinding.FragmentLicensesBinding
import com.razorEA.bot.model.License
import com.razorEA.bot.utils.LicenseManager

class LicensesFragment : DialogFragment() {

    private var _binding: FragmentLicensesBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = FragmentLicensesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupAddButton()
        binding.tvProfile.setOnClickListener { /* Open profile */ }
    }

    private fun setupRecyclerView() {
        val licenses = LicenseManager.getLicenses(requireContext())
        val adapter  = LicenseAdapter(licenses) { license ->
            LicenseManager.removeLicense(requireContext(), license.key)
            Toast.makeText(context, "License removed", Toast.LENGTH_SHORT).show()
            dismiss()
        }
        binding.rvLicenses.layoutManager = LinearLayoutManager(context)
        binding.rvLicenses.adapter = adapter
    }

    private fun setupAddButton() {
        binding.btnAddLicense.setOnClickListener {
            val key = binding.etLicenseKey.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(context, "Enter a license key", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            LicenseManager.addLicense(requireContext(), key) { success, msg ->
                activity?.runOnUiThread {
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    if (success) {
                        binding.etLicenseKey.text?.clear()
                        setupRecyclerView()
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

// ═══════════════════════════════════════════════════════════
// LICENSE ADAPTER
// ═══════════════════════════════════════════════════════════

class LicenseAdapter(
    private val items: List<License>,
    private val onDelete: (License) -> Unit
) : RecyclerView.Adapter<LicenseAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName:   android.widget.TextView = view.findViewById(R.id.tv_license_name)
        val tvKey:    android.widget.TextView = view.findViewById(R.id.tv_license_key)
        val tvExpiry: android.widget.TextView = view.findViewById(R.id.tv_license_expiry)
        val tvStatus: android.widget.TextView = view.findViewById(R.id.tv_license_status)
        val btnDel:   android.widget.ImageButton = view.findViewById(R.id.btn_license_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_license, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val lic = items[position]
        holder.tvName.text   = lic.botName
        holder.tvKey.text    = lic.maskedKey
        holder.tvExpiry.text = lic.expiryDate
        holder.tvStatus.text = if (lic.isActive) "Active" else "Expired"
        holder.tvStatus.setTextColor(
            if (lic.isActive) android.graphics.Color.parseColor("#00FF88")
            else android.graphics.Color.parseColor("#FF4444")
        )
        holder.btnDel.setOnClickListener { onDelete(lic) }
    }

    override fun getItemCount() = items.size
}

// ═══════════════════════════════════════════════════════════
// LOGS BOTTOM SHEET
// ═══════════════════════════════════════════════════════════

class LogsBottomSheet : com.google.android.material.bottomsheet.BottomSheetDialogFragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.bottom_sheet_logs, container, false)
        val rv = view.findViewById<RecyclerView>(R.id.rv_logs)
        val logs = com.razorEA.bot.network.MT5ConnectionService.instance.logs.value
        rv.layoutManager = LinearLayoutManager(context)
        rv.adapter = LogAdapter(logs)
        return view
    }
}

class LogAdapter(private val items: List<com.razorEA.bot.model.LogEntry>)
    : RecyclerView.Adapter<LogAdapter.VH>() {
    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tv: android.widget.TextView = v.findViewById(R.id.tv_log_entry)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_log, p, false))
    override fun onBindViewHolder(h: VH, pos: Int) {
        val e = items[pos]
        val ts = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US)
            .format(java.util.Date(e.timestamp))
        h.tv.text = "[$ts][${e.level.name}] ${e.message}"
        h.tv.setTextColor(when (e.level) {
            com.razorEA.bot.model.LogLevel.TRADE   -> android.graphics.Color.parseColor("#00FF88")
            com.razorEA.bot.model.LogLevel.ERROR   -> android.graphics.Color.parseColor("#FF4444")
            com.razorEA.bot.model.LogLevel.WARNING -> android.graphics.Color.YELLOW
            else -> android.graphics.Color.LTGRAY
        })
    }
    override fun getItemCount() = items.size
}

// ═══════════════════════════════════════════════════════════
// SYMBOLS BOTTOM SHEET
// ═══════════════════════════════════════════════════════════

class SymbolsBottomSheet : com.google.android.material.bottomsheet.BottomSheetDialogFragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.bottom_sheet_symbols, container, false)
        return view
    }
}

// ═══════════════════════════════════════════════════════════
// BOT SELECTOR BOTTOM SHEET
// ═══════════════════════════════════════════════════════════

class BotSelectorBottomSheet : com.google.android.material.bottomsheet.BottomSheetDialogFragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.bottom_sheet_bot_selector, container, false)
    }
}

// ═══════════════════════════════════════════════════════════
// CHART SCANNER ACTIVITY (stub — expandable)
// ═══════════════════════════════════════════════════════════

class ChartScannerActivity : androidx.appcompat.app.AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chart_scanner)
    }
}
