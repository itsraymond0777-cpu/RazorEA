package com.razorEA.bot.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.razorEA.bot.R
import com.razorEA.bot.databinding.FragmentHomeBinding
import com.razorEA.bot.model.*
import com.razorEA.bot.network.MT5ConnectionService
import com.razorEA.bot.service.TradingService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val conn = MT5ConnectionService.instance
    private var isRunning = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupButtons()
        observeData()
        animateHeroEntry()
    }

    // ════════════════════════════════════════════
    // BUTTON SETUP
    // ════════════════════════════════════════════

    private fun setupButtons() {

        // ── START / STOP ──────────────────────────────────────
        binding.btnStart.setOnClickListener {
            if (!isRunning) startEA() else stopEA()
        }

        // ── REMOVE ────────────────────────────────────────────
        binding.btnRemove.setOnClickListener {
            stopEA()
            (activity as? MainActivity)?.stopOverlayService()
            Toast.makeText(context, "Razor EA removed", Toast.LENGTH_SHORT).show()
        }

        // ── SYMBOLS ───────────────────────────────────────────
        binding.btnSymbols.setOnClickListener {
            SymbolsBottomSheet().show(parentFragmentManager, "symbols")
        }

        // ── LOGS ──────────────────────────────────────────────
        binding.btnLogs.setOnClickListener {
            LogsBottomSheet().show(parentFragmentManager, "logs")
        }

        // ── BOT SELECTOR ──────────────────────────────────────
        binding.cardBotSelector.setOnClickListener {
            BotSelectorBottomSheet().show(parentFragmentManager, "bot_select")
        }

        // ── AI CHART SCANNER ──────────────────────────────────
        binding.cardAiScanner.setOnClickListener {
            startActivity(Intent(requireContext(), ChartScannerActivity::class.java))
        }
    }

    // ════════════════════════════════════════════
    // EA CONTROL
    // ════════════════════════════════════════════

    private fun startEA() {
        val main = activity as? MainActivity ?: return
        // 1. Check overlay permission
        if (!Settings.canDrawOverlays(requireContext())) {
            main.requestOverlayPermission()
            return
        }
        // 2. Start services
        main.startTradingService()
        main.startOverlayService()
        isRunning = true
        updateStartButton(true)

        binding.tvStatusLabel.text = "RAZOR EA ACTIVE"
        binding.tvStatusLabel.setTextColor(resources.getColor(R.color.green_neon, null))
        pulseStartButton()
    }

    private fun stopEA() {
        val main = activity as? MainActivity ?: return
        main.stopTradingService()
        isRunning = false
        updateStartButton(false)
        binding.tvStatusLabel.text = "EA STOPPED"
        binding.tvStatusLabel.setTextColor(resources.getColor(R.color.text_secondary, null))
    }

    private fun updateStartButton(running: Boolean) {
        binding.btnStart.setImageResource(
            if (running) R.drawable.ic_stop else R.drawable.ic_play
        )
        val label = binding.root.findViewById<TextView>(R.id.tv_start_label)
        label?.text = if (running) "STOP" else "START"
    }

    private fun pulseStartButton() {
        val pulse = AnimationUtils.loadAnimation(context, R.anim.pulse)
        binding.btnStart.startAnimation(pulse)
    }

    // ════════════════════════════════════════════
    // OBSERVE LIVE DATA
    // ════════════════════════════════════════════

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            conn.tickFlow.collectLatest { tick ->
                if (tick.bid == 0.0) return@collectLatest
                binding.tvBid.text    = "%.2f".format(tick.bid)
                binding.tvAsk.text    = "%.2f".format(tick.ask)
                binding.tvSpread.text = "${tick.spread} pts"
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            conn.connectionState.collectLatest { state ->
                updateAccountBar(state)
            }
        }
    }

    private fun updateAccountBar(state: ConnectionState) {
        when (state.status) {
            ConnectionStatus.CONNECTED -> {
                binding.tvConnectionDot.setTextColor(
                    resources.getColor(R.color.green_neon, null))
                binding.tvConnectionDot.text = "●"
                binding.tvBalance.text = "${"%.2f".format(state.balance)} ${state.currency}"
                binding.tvEquity.text  = "${"%.2f".format(state.equity)} ${state.currency}"
                val pnl = state.equity - state.balance
                binding.tvFloating.text = "${if (pnl >= 0) "+" else ""}${"%.2f".format(pnl)}"
                binding.tvFloating.setTextColor(
                    if (pnl >= 0) resources.getColor(R.color.green_neon, null)
                    else resources.getColor(R.color.red_alert, null)
                )
            }
            ConnectionStatus.CONNECTING -> {
                binding.tvConnectionDot.setTextColor(resources.getColor(R.color.yellow_warn, null))
                binding.tvConnectionDot.text = "●"
            }
            ConnectionStatus.DISCONNECTED, ConnectionStatus.ERROR -> {
                binding.tvConnectionDot.setTextColor(resources.getColor(R.color.text_dim, null))
                binding.tvConnectionDot.text = "●"
                binding.tvBalance.text = "-- Connect MT5 --"
            }
        }
    }

    // ════════════════════════════════════════════
    // ANIMATIONS
    // ════════════════════════════════════════════

    private fun animateHeroEntry() {
        binding.heroImage.alpha = 0f
        binding.heroImage.animate()
            .alpha(1f)
            .setDuration(800)
            .setStartDelay(100)
            .start()

        binding.cardBotSelector.translationY = 80f
        binding.cardBotSelector.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(500)
            .setStartDelay(300)
            .start()

        binding.cardAiScanner.translationY = 80f
        binding.cardAiScanner.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(500)
            .setStartDelay(450)
            .start()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
