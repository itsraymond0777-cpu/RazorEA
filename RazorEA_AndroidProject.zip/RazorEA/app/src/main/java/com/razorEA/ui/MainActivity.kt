package com.razorEA.bot.ui

import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.razorEA.bot.R
import com.razorEA.bot.databinding.ActivityMainBinding
import com.razorEA.bot.service.OverlayService
import com.razorEA.bot.service.TradingService
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBottomNav()
        handleIntent(intent)

        // Default to Home
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }
    }

    private fun setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home        -> { loadFragment(HomeFragment()); true }
                R.id.nav_metatrader  -> { loadFragment(ConnectFragment()); true }
                R.id.nav_add        -> {
                    showAddMenu()
                    false
                }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(R.anim.fade_in, R.anim.fade_out)
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun handleIntent(intent: Intent?) {
        when (intent?.getStringExtra("tab")) {
            "trading" -> binding.bottomNav.selectedItemId = R.id.nav_home
        }
    }

    private fun showAddMenu() {
        LicensesFragment().show(supportFragmentManager, "licenses")
    }

    // ────────────────────────────────────────────
    // Overlay Permission Request
    // ────────────────────────────────────────────

    fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY)
        } else {
            startOverlayService()
        }
    }

    fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(intent)
        else
            startService(intent)
        Toast.makeText(this, "Razor EA overlay active ⚔", Toast.LENGTH_SHORT).show()
    }

    fun stopOverlayService() {
        stopService(Intent(this, OverlayService::class.java))
    }

    fun startTradingService() {
        val intent = Intent(this, TradingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(intent)
        else
            startService(intent)
    }

    fun stopTradingService() {
        stopService(Intent(this, TradingService::class.java))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startOverlayService()
            } else {
                Toast.makeText(this, "Overlay permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val REQ_OVERLAY = 1010
    }
}
