package com.razorEA.bot.utils

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.razorEA.bot.model.BrokerAccount
import com.razorEA.bot.model.License
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

// ═══════════════════════════════════════════════════════════
// SECURE PREFERENCES — AES256 encrypted storage
// ═══════════════════════════════════════════════════════════

object SecurePrefs {
    private const val FILE = "razor_secure"
    private val gson = Gson()

    private fun getPrefs(context: Context) = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context, FILE, masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback to regular prefs if encryption unavailable
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }

    fun saveAccount(context: Context, account: BrokerAccount) {
        getPrefs(context).edit()
            .putString("account", gson.toJson(account))
            .apply()
    }

    fun loadAccount(context: Context): BrokerAccount? {
        val json = getPrefs(context).getString("account", null) ?: return null
        return try { gson.fromJson(json, BrokerAccount::class.java) } catch (e: Exception) { null }
    }

    fun saveString(context: Context, key: String, value: String) {
        getPrefs(context).edit().putString(key, value).apply()
    }

    fun getString(context: Context, key: String, default: String = ""): String =
        getPrefs(context).getString(key, default) ?: default

    fun saveBoolean(context: Context, key: String, value: Boolean) {
        getPrefs(context).edit().putBoolean(key, value).apply()
    }

    fun getBoolean(context: Context, key: String, default: Boolean = false): Boolean =
        getPrefs(context).getBoolean(key, default)
}

// ═══════════════════════════════════════════════════════════
// LICENSE MANAGER
// ═══════════════════════════════════════════════════════════

object LicenseManager {
    private const val KEY_LICENSES = "licenses"
    private val gson = Gson()
    private val http = OkHttpClient()

    // Local demo/test key prefix
    private const val DEMO_PREFIX = "RAZOR-DEMO"

    fun getLicenses(context: Context): List<License> {
        val json = SecurePrefs.getString(context, KEY_LICENSES, "[]")
        return try {
            val type = object : com.google.gson.reflect.TypeToken<List<License>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    fun addLicense(context: Context, key: String, callback: (Boolean, String) -> Unit) {
        // Demo key validation (offline)
        if (key.startsWith(DEMO_PREFIX)) {
            val license = License(
                key        = key,
                botName    = "Razor EA",
                maskedKey  = maskKey(key),
                expiryDate = "Mar 25, 2027",
                isActive   = true
            )
            saveLicense(context, license)
            callback(true, "Demo license activated ✓")
            return
        }

        // Online validation
        Thread {
            try {
                val req = Request.Builder()
                    .url("https://api.razorEA.com/license/validate?key=$key")
                    .build()
                val resp = http.newCall(req).execute()
                if (resp.isSuccessful) {
                    val body = resp.body()?.string() ?: "{}"
                    val result = gson.fromJson(body, LicenseResponse::class.java)
                    if (result.valid) {
                        val license = License(
                            key        = key,
                            botName    = result.botName ?: "Razor EA",
                            maskedKey  = maskKey(key),
                            expiryDate = result.expiry ?: "Unknown",
                            isActive   = true
                        )
                        saveLicense(context, license)
                        callback(true, "License activated: ${result.botName}")
                    } else {
                        callback(false, "Invalid or expired license key")
                    }
                } else {
                    callback(false, "Server error — check your key")
                }
            } catch (e: Exception) {
                // Offline fallback: accept key if format valid
                if (key.length >= 12) {
                    val license = License(
                        key        = key,
                        botName    = "Razor EA",
                        maskedKey  = maskKey(key),
                        expiryDate = "Mar 25, 2027",
                        isActive   = true
                    )
                    saveLicense(context, license)
                    callback(true, "License saved (offline mode)")
                } else {
                    callback(false, "Network error and key too short")
                }
            }
        }.start()
    }

    fun removeLicense(context: Context, key: String) {
        val current = getLicenses(context).toMutableList()
        current.removeAll { it.key == key }
        SecurePrefs.saveString(context, KEY_LICENSES, gson.toJson(current))
    }

    private fun saveLicense(context: Context, license: License) {
        val current = getLicenses(context).toMutableList()
        if (current.none { it.key == license.key }) current.add(license)
        SecurePrefs.saveString(context, KEY_LICENSES, gson.toJson(current))
    }

    private fun maskKey(key: String): String {
        if (key.length <= 8) return key
        val parts = key.split("-")
        return if (parts.size >= 3) {
            "${parts[0]}--****-${parts.last()}"
        } else {
            "${key.take(3)}--****-${key.takeLast(4)}"
        }
    }

    data class LicenseResponse(
        val valid: Boolean = false,
        val botName: String? = null,
        val expiry: String? = null
    )
}
